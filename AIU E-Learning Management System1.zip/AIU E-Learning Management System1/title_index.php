				
								<div class="row-fluid">

						<div class="span12">
						
						</div>	
													
							</div>
							<div class="row-fluid">

						<div class="span4">
						<img class="index_logo" src="admin/images/Logo.png">
						</div>	
						<div class="span8">
						
								<div class="title">
							<p class="chmsc">Empowering Minds, Inspiring Futures</p>
							<h1>

							<p>AIU E-Learning </p>
						
							</h1>		
						</div>

			
						</div>							
							</div>
				
				<div class="row-fluid">

						<div class="span12">
						<br>
								<div class="motto">
											<h3>
												<p>AIU EXCELS:</p>
											</h3>
												<p>Excellence, Competence and Educational</p>
												<p>Leadership in Science and Technology</p>
								</div>		
						</div>		
				</div>