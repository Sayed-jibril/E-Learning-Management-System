<center>
		<footer>
		
		<p>AIU E-Learning Copyright 2024</p>
			<!-- <p>Programmed by: Mohammed Siad (Hasa Team)</p> -->
		</footer>
</center>

