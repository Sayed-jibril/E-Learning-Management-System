<?php include('header_dashboard.php'); ?>
    <body id="class_div">
		<?php include('navbar_about.php'); ?>
        <div class="container-fluid">
            <div class="row-fluid">
                <div class="span12" id="content">
                     <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
								<div class="navbar navbar-inner block-header">
									<div id="" class="muted pull-right"><a href="index.php"><i class="icon-arrow-left"></i> Back</a></div>
								</div>
                            <div class="block-content collapse in">
							<h3>Developers</h3>
							<hr>
                                <div class="span3">
										<center>
										<img id="developers" src="admin/images/jkev.jpg" class="img-circle">
										<hr>
										<p>Name: Mohammed Siad Jibril</p>
										<p>Address: Alor Setar</p>
										<p>Email: mohamedjibril820@gmail.com</p>
										<p>Position: Project Manager & Programmer</p>
										</center>

								</div>
								<div class="span3">
										<center>
										<img id="developers" src="admin/images/jdev.jpg" class="img-circle">
										<hr>
										<p>Name: Asad Mohamed</p>
										<p>Address: Alor Setar</p>
										<p>Email: asad.adan@student.aiu.edu.my</p>
										<p>Position: Programmer</p>
										</center>
								</div>
                                <div class="span3">
															<center>
								<img id="developers" src="admin/images/jelyn.jpg" class="img-circle">
								<hr>
																				<p>Name: Abdoulaye Saleh</p>

										<p>Address: Alor Setar</p>
										<p>Email: abdoulaye.saleh@student.aiu.edu.my</p>
										<p>Position: Programmer</p>
								</center>
								</div>
                                <div class="span3">
															<center>
								<img id="developers" src="admin/images/jorge.jpg" class="img-circle">
								<hr>
												<p>Name: Mohamed Arefin</p>
										<p>Address: Alor Setar</p>
										<p>Email: saiful.arefin@student.aiu.edu.my</p>
										<p>Position: Programmer</p>
								</center>
								</div>
                                <div class="span3">
															<center>
								<img id="developers" src="admin/images/mich.jpg" class="img-circle">
								<hr>
												<p>Name: Habib Idriss</p>
										<p>Address: Alor Setar</p>
										<p>Email: habib.daoud@student.aiu.edu.my</p>
										<p>Position: Programmer</p>
								</center>
								</div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                </div>
            </div>
		<?php include('footer.php'); ?>
        </div>
		<?php include('script.php'); ?>
    </body>
</html>